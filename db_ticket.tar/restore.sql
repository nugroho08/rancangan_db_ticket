--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.11
-- Dumped by pg_dump version 10.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.type_transportasi DROP CONSTRAINT type_transportasi_pkey;
ALTER TABLE ONLY public.transportasi DROP CONSTRAINT transportasi_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.penumpang DROP CONSTRAINT penumpang_pkey;
ALTER TABLE ONLY public.pemesanan DROP CONSTRAINT pemesanan_pkey;
DROP TABLE public.type_transportasi;
DROP TABLE public.transportasi;
DROP TABLE public.tb_level;
DROP TABLE public.rute;
DROP TABLE public.petugas;
DROP TABLE public.penumpang;
DROP TABLE public.pemesanan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pemesanan (
    id_pemesanan integer NOT NULL,
    kode_pemesanan integer,
    tanggal_pemesanan date,
    tempat_pemesanan character varying(20),
    id_pelanggan integer,
    kode_kursi character varying(5),
    id_rute integer,
    tujuan character varying(32),
    tanggal_berangkat date,
    jam_cekin time without time zone,
    jam_berangkat time without time zone,
    total_bayar character varying(20),
    id_petugas integer
);


ALTER TABLE public.pemesanan OWNER TO postgres;

--
-- Name: penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.penumpang (
    id_penumpang integer NOT NULL,
    username character varying(16),
    password character varying(16),
    nama_penumpang character varying(32),
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character varying(16),
    tlephone character varying(12)
);


ALTER TABLE public.penumpang OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petugas (
    id_petugas integer NOT NULL,
    username character varying(16),
    password character varying(16),
    nama_petugas character varying(32),
    id_level integer
);


ALTER TABLE public.petugas OWNER TO postgres;

--
-- Name: rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rute (
    id_rute integer,
    tujuan character varying(32),
    rute_awal character varying(15),
    rute_ahir character varying(15),
    harga character varying(15),
    id_transportasi integer
);


ALTER TABLE public.rute OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_level (
    id_level integer NOT NULL,
    nama_level character varying(15)
);


ALTER TABLE public.tb_level OWNER TO postgres;

--
-- Name: transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transportasi (
    id_transportasi integer NOT NULL,
    kode character varying(10),
    jumlah_kursi integer,
    keterangan text,
    id_typr_transportasi integer
);


ALTER TABLE public.transportasi OWNER TO postgres;

--
-- Name: type_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_transportasi (
    id_type_transportasi integer NOT NULL,
    nama_type character varying(15),
    keterangan text
);


ALTER TABLE public.type_transportasi OWNER TO postgres;

--
-- Data for Name: pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY public.pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, tlephone) FROM stdin;
\.
COPY public.penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, tlephone) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY public.petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rute (id_rute, tujuan, rute_awal, rute_ahir, harga, id_transportasi) FROM stdin;
\.
COPY public.rute (id_rute, tujuan, rute_awal, rute_ahir, harga, id_transportasi) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_level (id_level, nama_level) FROM stdin;
\.
COPY public.tb_level (id_level, nama_level) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_typr_transportasi) FROM stdin;
\.
COPY public.transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_typr_transportasi) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: type_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type_transportasi (id_type_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY public.type_transportasi (id_type_transportasi, nama_type, keterangan) FROM '$$PATH$$/2834.dat';

--
-- Name: pemesanan pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: penumpang penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.penumpang
    ADD CONSTRAINT penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: transportasi transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transportasi
    ADD CONSTRAINT transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- Name: type_transportasi type_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_transportasi
    ADD CONSTRAINT type_transportasi_pkey PRIMARY KEY (id_type_transportasi);


--
-- PostgreSQL database dump complete
--

